$ErrorActionPreference='Stop'
$Installer = Resolve-Path 'PizzaOS-Setup-0.1.0-x64.exe'
$InstallRoot = Join-Path $env:LOCALAPPDATA 'Programs\PizzaOS'
$p=Start-Process -Wait -PassThru -FilePath $Installer -ArgumentList '/S'
if($p.ExitCode -ne 0){throw 'Silent install failed'}
if(!(Test-Path "$InstallRoot\runtime\node.exe")){throw 'Bundled node missing'}
# Exercise the shipped launcher, not a substitute node command.
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$InstallRoot\launcher.ps1"
$loginPath=Join-Path $env:LOCALAPPDATA 'PizzaOS\data\FIRST-LOGIN.txt'
$password=((Get-Content $loginPath | Where-Object {$_ -like 'Password: *'}) -replace '^Password: ','').Trim()
if(!$password){throw 'No generated first login'}
Get-Process notepad -ErrorAction SilentlyContinue | Stop-Process -Force
$session=New-Object Microsoft.PowerShell.Commands.WebRequestSession
function Post($path,$data,$key){$headers=@{};if($key){$headers['Idempotency-Key']=$key};Invoke-RestMethod -Uri ('http://127.0.0.1:4180/api'+$path) -Method Post -WebSession $session -ContentType 'application/json' -Headers $headers -Body ($data | ConvertTo-Json -Depth 20)}
Post '/auth/login' @{email='owner@ember-pizza.local';password=$password} | Out-Null
$newPassword=[Guid]::NewGuid().ToString()+'Aa1!'
Post '/password' @{current=$password;password=$newPassword} | Out-Null
$session=New-Object Microsoft.PowerShell.Commands.WebRequestSession
Post '/auth/login' @{email='owner@ember-pizza.local';password=$newPassword} | Out-Null
$product=(Invoke-RestMethod 'http://127.0.0.1:4180/api/menu' -WebSession $session).products[0]
$order=Post '/orders' @{channel='pickup';customer='Windows Synthetic Guest';items=@(@{product=$product.id;quantity=1})} ([Guid]::NewGuid().ToString())
if(!$order.id){throw 'Write failed'}
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$InstallRoot\stop.ps1"
Start-Sleep -Seconds 1
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$InstallRoot\launcher.ps1"
$session=New-Object Microsoft.PowerShell.Commands.WebRequestSession
Post '/auth/login' @{email='owner@ember-pizza.local';password=$newPassword} | Out-Null
$orders=Invoke-RestMethod 'http://127.0.0.1:4180/api/orders' -WebSession $session
if(!($orders | Where-Object {$_.id -eq $order.id})){throw 'Restart lost persisted order'}
# Capture actual installed app pixels after persistent order readback.
$env:PIZZAOS_UI_PASSWORD=$newPassword
& "$InstallRoot\runtime\node.exe" ui-tools/windows-ui.mjs
if($LASTEXITCODE -ne 0){throw 'Installed UI check failed'}
Remove-Item Env:PIZZAOS_UI_PASSWORD
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$InstallRoot\stop.ps1"
# Install upgrade over existing app and verify data remains, then uninstall keeps data.
Start-Process -Wait -FilePath $Installer -ArgumentList '/S'
$dataPath=Join-Path $env:LOCALAPPDATA 'PizzaOS\data\pizzaos.db'
if(!(Test-Path $dataPath)){throw 'Upgrade removed data'}
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$InstallRoot\launcher.ps1"
$session=New-Object Microsoft.PowerShell.Commands.WebRequestSession
Post '/auth/login' @{email='owner@ember-pizza.local';password=$newPassword} | Out-Null
$orders=Invoke-RestMethod 'http://127.0.0.1:4180/api/orders' -WebSession $session
if(!($orders | Where-Object {$_.id -eq $order.id})){throw 'Upgrade lost persisted order'}
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$InstallRoot\stop.ps1"
$uninstall=Start-Process -PassThru -Wait "$InstallRoot\Uninstall.exe" -ArgumentList '/S'
Start-Sleep -Seconds 3
if(!(Test-Path $dataPath)){throw 'Uninstall deleted user data'}
Write-Output 'WINDOWS_SMOKE_PASS: installed launcher login password-change write stop restart readback upgrade uninstall-data-preservation'
