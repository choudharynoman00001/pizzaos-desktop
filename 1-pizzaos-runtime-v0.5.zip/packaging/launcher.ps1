$ErrorActionPreference = 'Stop'
$AppRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$DataRoot = Join-Path $env:LOCALAPPDATA 'PizzaOS\data'
New-Item -ItemType Directory -Force -Path $DataRoot | Out-Null
$env:PIZZAOS_DB = Join-Path $DataRoot 'pizzaos.db'
$env:PORT = '4180'
$env:HOST = '127.0.0.1'
try {
  $response = Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:4180/' -TimeoutSec 1
  if ($response.Content -notmatch '<title>PizzaOS') { throw 'Port 4180 is in use by another application. Close it before starting PizzaOS.' }
  Start-Process 'http://localhost:4180'
  exit 0
} catch {
  if ($_.Exception.Message -match 'Port 4180') { throw }
}
$log = Join-Path $DataRoot 'server.log'
$errlog = Join-Path $DataRoot 'server-error.log'
$process = Start-Process -FilePath (Join-Path $AppRoot 'runtime\node.exe') -ArgumentList ('"' + (Join-Path $AppRoot 'server.mjs') + '"') -WorkingDirectory $AppRoot -PassThru -WindowStyle Hidden -RedirectStandardOutput $log -RedirectStandardError $errlog
$ready = $false
for ($i = 0; $i -lt 60; $i++) {
  Start-Sleep -Milliseconds 200
  if ($process.HasExited) { break }
  try { $response = Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:4180/' -TimeoutSec 1; if ($response.Content -match '<title>PizzaOS') { $ready = $true; break } } catch {}
}
if (!$ready) { Start-Process notepad.exe $errlog; throw 'PizzaOS did not start. See the error log in your local PizzaOS data folder.' }
if (!(Test-Path (Join-Path $DataRoot 'login-shown'))) {
  Start-Process notepad.exe (Join-Path $DataRoot 'FIRST-LOGIN.txt')
  Set-Content -Path (Join-Path $DataRoot 'login-shown') -Value 'shown'
}
Set-Content -Path (Join-Path $DataRoot 'server.pid') -Value $process.Id
Start-Process 'http://localhost:4180'
