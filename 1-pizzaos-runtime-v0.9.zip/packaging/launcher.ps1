$ErrorActionPreference = 'Stop'
$AppRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$DataRoot = Join-Path $env:LOCALAPPDATA 'PizzaOS\data'
New-Item -ItemType Directory -Force -Path $DataRoot | Out-Null
$env:PIZZAOS_DB = Join-Path $DataRoot 'pizzaos.db'
$env:PORT = '4180'
$env:HOST = '127.0.0.1'
# Browser-engine application window, not a native desktop UI. No cache/service worker.
function Open-PizzaWindow {
  $candidates = @(
    (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'),
    (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe'),
    (Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\Application\msedge.exe'),
    (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'),
    (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')
  )
  $browser = $candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
  $url = 'http://127.0.0.1:4180/'
  if ($browser) {
    $arguments = @('--app=' + $url)
    if ($env:PIZZAOS_TEST_BROWSER_PROFILE) {
      # A separate disposable profile permits bounded ownership proof and cleanup in CI.
      $arguments += @('--user-data-dir="' + $env:PIZZAOS_TEST_BROWSER_PROFILE + '"', '--no-first-run', '--no-default-browser-check')
    }
    Set-Content -Path (Join-Path $DataRoot 'last-launch.txt') -Value ('mode=app-window (browser engine)' + [Environment]::NewLine + $browser + [Environment]::NewLine + ($arguments -join ' '))
    Start-Process -FilePath $browser -ArgumentList $arguments | Out-Null
  } else {
    Set-Content -Path (Join-Path $DataRoot 'last-launch.txt') -Value ('mode=fallback default-browser window' + [Environment]::NewLine + $url)
    Add-Type -AssemblyName PresentationFramework
    [System.Windows.MessageBox]::Show('Edge or Chrome was not found. PizzaOS will open in your normal browser instead of a separate app window. Your saved data is unchanged.','PizzaOS browser fallback') | Out-Null
    Start-Process $url | Out-Null
  }
}
try {
  $response = Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:4180/' -TimeoutSec 1
  if ($response.Content -notmatch '<title>PizzaOS') { throw 'Port 4180 is in use by another application. Close it before starting PizzaOS.' }
  Open-PizzaWindow
  exit 0
} catch {
  if ($_.Exception.Message -match 'Port 4180') { throw }
}
$log = Join-Path $DataRoot 'server.log'
$errlog = Join-Path $DataRoot 'server-error.log'
$process = Start-Process -FilePath (Join-Path $AppRoot 'runtime\node.exe') -ArgumentList ('"' + (Join-Path $AppRoot 'server.mjs') + '"') -WorkingDirectory $AppRoot -PassThru -WindowStyle Hidden -RedirectStandardOutput $log -RedirectStandardError $errlog
$ready = $false
for ($i = 0; $i -lt 60; $i++) {
  Start-Sleep -Milliseconds 200
  if ($process.HasExited) { break }
  try { $response = Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:4180/' -TimeoutSec 1; if ($response.Content -match '<title>PizzaOS') { $ready = $true; break } } catch {}
}
if (!$ready) { Start-Process notepad.exe $errlog; throw 'PizzaOS did not start. See the error log in your local PizzaOS data folder.' }
if (!(Test-Path (Join-Path $DataRoot 'login-shown'))) {
  Start-Process notepad.exe (Join-Path $DataRoot 'FIRST-LOGIN.txt')
  Set-Content -Path (Join-Path $DataRoot 'login-shown') -Value 'shown'
}
Set-Content -Path (Join-Path $DataRoot 'server.pid') -Value $process.Id
Open-PizzaWindow
