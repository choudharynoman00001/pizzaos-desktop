Unicode True
!include "MUI2.nsh"
Name "PizzaOS Development Preview"
OutFile "/downloads/pizzaos-delivery/PizzaOS-Setup-0.1.0-x64.exe"
InstallDir "$LOCALAPPDATA\Programs\PizzaOS"
RequestExecutionLevel user
SetCompressor /SOLID lzma
!define MUI_ABORTWARNING
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_LICENSE "../docs/WINDOWS-NOTICE.txt"
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!define MUI_FINISHPAGE_RUN
!define MUI_FINISHPAGE_RUN_FUNCTION LaunchApp

!define MUI_FINISHPAGE_RUN_TEXT "Start PizzaOS (local development preview)"
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"
Section "PizzaOS application"
SetOutPath "$INSTDIR"
File /r "/tmp/pizzaos-win-stage/*"
WriteUninstaller "$INSTDIR\Uninstall.exe"
CreateDirectory "$SMPROGRAMS\PizzaOS"
CreateShortcut "$SMPROGRAMS\PizzaOS\PizzaOS.lnk" "$WINDIR\System32\wscript.exe" '"$INSTDIR\Launch-PizzaOS.vbs"'
CreateShortcut "$DESKTOP\PizzaOS.lnk" "$WINDIR\System32\wscript.exe" '"$INSTDIR\Launch-PizzaOS.vbs"'
CreateShortcut "$SMPROGRAMS\PizzaOS\Stop PizzaOS.lnk" "$WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe" '-NoProfile -ExecutionPolicy Bypass -File "$INSTDIR\stop.ps1"'
CreateShortcut "$SMPROGRAMS\PizzaOS\Uninstall PizzaOS.lnk" "$INSTDIR\Uninstall.exe"
WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\PizzaOS" "DisplayName" "PizzaOS Development Preview"
WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\PizzaOS" "UninstallString" '"$INSTDIR\Uninstall.exe"'
WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\PizzaOS" "Publisher" "Alpha Blue Digital"
SectionEnd
Section "Uninstall"
ExecWait '"$WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "$INSTDIR\stop.ps1"'
Delete "$DESKTOP\PizzaOS.lnk"
RMDir /r "$SMPROGRAMS\PizzaOS"
RMDir /r "$INSTDIR"
DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\PizzaOS"
IfSilent +2
MessageBox MB_OK "PizzaOS program removed. Your restaurant data is kept in %LOCALAPPDATA%\PizzaOS\data. It has not been deleted."
SectionEnd

Function LaunchApp
Exec '"$WINDIR\System32\wscript.exe" "$INSTDIR\Launch-PizzaOS.vbs"'
FunctionEnd
