$ErrorActionPreference = 'Stop'
$pidFile = Join-Path $env:LOCALAPPDATA 'PizzaOS\data\server.pid'
if (Test-Path $pidFile) {
  $ServerId = [int](Get-Content $pidFile)
  $process = Get-CimInstance Win32_Process -Filter "ProcessId=$ServerId"
  $ExpectedRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
  if ($process -and $process.ExecutablePath -eq (Join-Path $ExpectedRoot 'runtime\node.exe') -and $process.CommandLine.Contains((Join-Path $ExpectedRoot 'server.mjs'))) { Stop-Process -Id $ServerId }
  Remove-Item $pidFile -ErrorAction SilentlyContinue
}
